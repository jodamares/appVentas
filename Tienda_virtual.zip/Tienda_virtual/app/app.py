from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import os

app = Flask(__name__)

# Configura la clave secreta para manejar sesiones
app.secret_key = 'secreta'  # Cambia esto a una clave segura

# Definir la carpeta donde se almacenarán las imágenes
app.config['UPLOAD_FOLDER'] = 'static\imagenes'

# Configuración de conexión a la base de datos MySQL
app.config['MYSQL_HOST'] = 'localhost'  # Cambia a tu host de base de datos
app.config['MYSQL_USER'] = 'root'       # Cambia a tu usuario
app.config['MYSQL_PASSWORD'] = 'root'  # Cambia a tu contraseña
app.config['MYSQL_DB'] = 'tienda_virtual'  # Cambia por el nombre de tu base de datos


mysql = MySQL(app)

@app.route('/')
def ver_productos():
    cur = mysql.connection.cursor()
    cur.execute("SELECT nombre, imagen, precio, cantidad FROM productos")
    productos = cur.fetchall()
    cur.close()
    return render_template('ver_productos.html', productos=productos)

@app.route('/agregar', methods=['GET', 'POST'])
def agregar_producto():
    if request.method == 'POST':
        nombre = request.form['nombre']
        precio = request.form['precio']
        cantidad = request.form['cantidad']

        # Subida de la imagen
        imagen = request.files['imagen']
        if imagen:
            # Guardar la imagen en la carpeta 'static/imagenes'
            imagen_filename = imagen.filename
            imagen_path = os.path.join(app.config['UPLOAD_FOLDER'], imagen_filename)
            
            # Asegúrate de que la carpeta existe antes de guardar la imagen
            if not os.path.exists(app.config['UPLOAD_FOLDER']):
                os.makedirs(app.config['UPLOAD_FOLDER'])
                
            imagen.save(imagen_path)

            # Guardar los datos del producto en la base de datos existente
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO productos (nombre, imagen, precio, cantidad) VALUES (%s, %s, %s, %s)",
                        (nombre, imagen_filename, precio, cantidad))
            mysql.connection.commit()
            cur.close()

            return redirect(url_for('ver_productos'))

    return render_template('agregar_producto.html')

@app.route('/agregar_al_carrito', methods=['POST'])
def agregar_al_carrito():
    producto_id = request.form['codigo']
    cantidad = int(request.form['cantidad'])
    
    # Crear el carrito en la sesión si no existe
    if 'carrito' not in session:
        session['carrito'] = {}

    # Agregar o actualizar el producto en el carrito
    if producto_id in session['carrito']:
        # Si el producto ya está en el carrito, actualizar la cantidad
        session['carrito'][producto_id] += cantidad
    else:
        # Si el producto no está en el carrito, agregarlo
        session['carrito'][producto_id] = cantidad

    # Redirigir a la página anterior o a una página específica
    return redirect(url_for('mostrar_carrito'))


@app.route('/mostrar_carrito')
def mostrar_carrito():
    carrito = session.get('carrito', {})
    
    # Aquí podrías obtener los detalles de los productos desde la base de datos
    return f"Carrito actual: {carrito}"



if __name__ == '__main__':
   app.run(debug=True, port=5000)
