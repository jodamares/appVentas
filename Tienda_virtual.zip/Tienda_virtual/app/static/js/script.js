document.querySelectorAll('.btnAgregar').forEach(function(button) {
    button.addEventListener('click', function() {
        var form = this.closest('.agregarCarrito');
        var codigo = form.getAttribute('data-product-codigo');

        fetch(`/producto/codigo/${codigo}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Producto no encontrado');
                }
                return response.json();
            })
            .then(producto => {
                // Llenar el formulario con los datos del producto
                document.getElementById('nombre').value = producto.nombre;
                document.getElementById('precio').value = producto.precio;
                document.getElementById('codigo').value = producto.codigo;
                document.getElementById('productoDetalles').style.display = 'block'; // Mostrar el formulario
            })
            .catch(error => console.error(error));
    });
});

// Manejar el envío del formulario (agregar lógica para agregar al carrito)
document.getElementById('formProducto').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Producto agregado al carrito: ' + document.getElementById('nombre').value);
});
